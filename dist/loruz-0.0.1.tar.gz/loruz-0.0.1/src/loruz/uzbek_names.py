# Uzbek names
first_names = [
    'Adil',
    'Ahmad',
    'Alisher',
]

last_names = [
    'Abdullayev',
    'Abdullayev',
    'Abdullayev',
]
