import random

def generate_phone_number(mobile=True):
    """
    Generates a random Uzbek phone number (mobile or landline).

    Args:
        mobile: Optional boolean flag specifying whether to generate a mobile number.

    Returns:
        A string containing the generated phone number.
    """
    # Define Uzbek mobile and landline number formats
    mobile_format = f"+998{random.randint(90, 99)}{random.randint(100000, 999999)}"
    landline_format = f"+998{random.randint(71, 75)}{random.randint(100000, 999999)}"

    if mobile:
        return mobile_format
    else:
        return landline_format
