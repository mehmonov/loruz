from names import generate_name
from addresses import generate_address
from phone_numbers import generate_phone_number
# from text import generate_text

def generate_fake_data(data_type, topic=None):
    """
    Generates fake Uzbek data based on the data type and optional topic.

    Args:
        data_type: String specifying the type of data to generate (e.g., "name", "address").
        topic: Optional string specifying the topic of the data (e.g., "finance").

    Returns:
        A dictionary containing generated data.
    """
    if data_type == "name":
        names = f"{generate_name(topic)} "
        return names
    elif data_type == "address":
        return {"address": generate_address(topic)}
    elif data_type == "phone_number":
        return generate_phone_number()

if __name__ == "__main__":
    for _ in range(10):
        print(generate_fake_data("name"))
        print(generate_fake_data("address"))
        print(generate_fake_data("phone_number"))