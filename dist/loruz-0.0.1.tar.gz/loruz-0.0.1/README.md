# Faker datas

This is fake data generated in uzbek languages