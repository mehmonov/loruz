def text():
    return "salom dunyo "