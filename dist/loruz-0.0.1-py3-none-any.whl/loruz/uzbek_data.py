# Uzbek locations
regions = [
    'Namangan',
    'Andijon',
    'Sirdaryo',
    'Surxondaryo',
    'Toshkent',
]

cities = {
    'Namangan': ['Namangan shahri', 'Uychi', 'Turakurgan'],
    'Andijon': ['Andijon shahri', 'Asaka', 'Buloqboshi'],
    'Sirdaryo': ['Guliston', 'Sirdaryo', 'Boysun'],
    'Surxondaryo': ['Termiz', 'Denov', 'Sherobod'],
    'Toshkent': ['Toshkent shahri', 'Chirchiq', 'Yangiyol'],
}

streets = [
    'Nukus',
    'Toshkent',
    'Chilonzor',
]

domain_names = [
    'uz',
]
