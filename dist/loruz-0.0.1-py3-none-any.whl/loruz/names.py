import random

from uzbek_names import first_names, last_names

def generate_name(topic=None):
    """
    Generates a random Uzbek name (first and last).

    Args:
        topic: Optional string specifying the topic of the data.

    Returns:
        A string containing the generated name.
    """
    # Apply topic-specific logic if needed (e.g., specific first names for finance)

    first_name = random.choice(first_names)
    last_name = random.choice(last_names)
    return f"{first_name} {last_name}"

if __name__ == "__main__":
    print(generate_name())