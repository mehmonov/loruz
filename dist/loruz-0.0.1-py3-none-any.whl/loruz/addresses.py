import random

from uzbek_data import regions, cities, streets

def generate_address(topic=None):
    """
    Generates a random Uzbek address (region, city, street, postal code).

    Args:
        topic: Optional string specifying the topic of the data.

    Returns:
        A dictionary containing the address components.
    """

    region = random.choice(regions)
    city = random.choice(cities[region])
    street = random.choice(streets)
    postal_code = f"UZ-{random.randint(10000, 99999)}"
    address = f"Viloyat: {region}, Shahar: {city}, Ko'cha: {street}, Pochta manzili: {postal_code}"
    return address

if __name__ == "__main__":
    print(generate_address())